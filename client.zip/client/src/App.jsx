
import './App.css'

function App() {
  

  return (
  <main className= 'text-blue-500 text-3x1 font-bold'>
    Vite App Hello World
  </main>
  )
}

export default App
